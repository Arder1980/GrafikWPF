﻿namespace GrafikWPF
{
    public record AlgorithmInfo(
        string Nazwa,
        string TypAlgorytmu,
        string Powtarzalnosc,
        string Wielowatkowosc,
        string JakoscGwarancja,
        string CzasUzyskaniaWyniku,
        string UzyciePamieci
    );
}