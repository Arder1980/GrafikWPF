﻿namespace GrafikWPF
{
    public enum SolverType
    {
        Backtracking,
        AStar,
        Genetic,
        SimulatedAnnealing,
        TabuSearch,
        AntColony
    }
}