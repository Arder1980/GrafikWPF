﻿namespace GrafikWPF
{
    public enum TypDostepnosci
    {
        Niedostepny,      // ---
        Moge,             // X
        Chce,             // XXX
        BardzoChce,       // Nowy, najwyższy priorytet
        Urlop,            // U
        DyzurInny,        // D
        MogeWarunkowo     // W
    }
}