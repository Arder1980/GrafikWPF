﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;

namespace GrafikWPF
{
    public partial class WyborAlgorytmuWindow : Window, INotifyPropertyChanged
    {
        public class AlgorithmChoice : INotifyPropertyChanged
        {
            public SolverType Type { get; set; }
            public string Name { get; set; } = string.Empty;
            public string Description { get; set; } = string.Empty;
            public object DescriptionHeader { get; set; } = new TextBlock();

            private bool _isSelected;
            public bool IsSelected
            {
                get => _isSelected;
                set { _isSelected = value; OnPropertyChanged(); }
            }

            public event PropertyChangedEventHandler? PropertyChanged;
            protected void OnPropertyChanged([CallerMemberName] string? name = null)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
            }
        }

        public List<AlgorithmChoice> AlgorithmOptions { get; set; }
        public List<AlgorithmInfo> ComparisonData { get; set; }
        public SolverType SelectedAlgorithm => AlgorithmOptions.First(o => o.IsSelected).Type;

        private AlgorithmChoice? _activeDescription;
        public AlgorithmChoice? ActiveDescription
        {
            get => _activeDescription;
            set { _activeDescription = value; OnPropertyChanged(nameof(ActiveDescription)); }
        }

        public WyborAlgorytmuWindow(SolverType currentSolver)
        {
            InitializeComponent();
            this.DataContext = this;

            AlgorithmOptions = new List<AlgorithmChoice>
            {
                new AlgorithmChoice
                {
                    Type = SolverType.Backtracking,
                    Name = "BacktrackingSolver",
                    DescriptionHeader = CreateHeader("BacktrackingSolver", "algorytm z nawrotami"),
                    Description = "Klasyczny algorytm z nawrotami (backtracking), który systematycznie, dzień po dniu, buduje grafik w porządku chronologicznym, tworząc w ten sposób drzewo wszystkich możliwych rozwiązań. Gdy dotrze do ślepego zaułka (np. dnia, którego nie da się obsadzić), cofa się do ostatniego punktu decyzyjnego i próbuje innej ścieżki. Jego kluczową optymalizacją jest przycinanie (pruning) – odrzucanie całych gałęzi drzewa, które nie mogą doprowadzić do lepszego wyniku niż już znaleziony. Dzięki pełnemu przeszukiwaniu, daje gwarancję znalezienia absolutnie najlepszego grafiku. Jego prostota i szybkość sprawiają, że jest idealny dla mniej złożonych problemów. Przy dużej liczbie lekarzy i deklaracji jego czas działania może być jednak bardzo długi i przekroczyć predefiniowany limit 30 sekund, co spowoduje automatyczne przerwanie pracy silnika."
                },
                new AlgorithmChoice
                {
                    Type = SolverType.AStar,
                    Name = "AStarSolver",
                    DescriptionHeader = CreateHeader("AStarSolver", "wielokryterialny algorytm A*"),
                    Description = "Zaawansowany algorytm przeszukiwania grafu, który inteligentnie eksploruje najbardziej obiecujące ścieżki. Działa na wielowymiarowym wektorze kosztów, porównując grafiki zgodnie z ustawioną hierarchią priorytetów (tzw. porównanie leksykograficzne). Używa 'ważonej' heurystyki, co pozwala mu na bardzo szybkie znalezienie rozwiązań o wysokiej jakości, bliskich optimum, w zamian za niewielkie, teoretyczne ryzyko pominięcia absolutnie najlepszego rozwiązania. Stanowi doskonały kompromis między szybkością a jakością."
                },
                new AlgorithmChoice
                {
                    Type = SolverType.Genetic,
                    Name = "GeneticSolver",
                    DescriptionHeader = CreateHeader("GeneticSolver", "algorytm genetyczny"),
                    Description = "Ta implementacja opiera się na procesie ewolucji naturalnej. Operuje na całej 'populacji' kompletnych grafików, które 'krzyżuje' i 'mutuje', naśladując ewolucję w poszukiwaniu najlepszego rozwiązania. Jest bardzo szybki, choć nie gwarantuje znalezienia wyniku idealnego (zwykle jest on jednak bardzo bliski)."
                },
                new AlgorithmChoice
                {
                    Type = SolverType.SimulatedAnnealing,
                    Name = "SimulatedAnnealingSolver",
                    DescriptionHeader = CreateHeader("SimulatedAnnealingSolver", "algorytm symulowanego wyżarzania"),
                    Description = "Metaheurystyka naśladująca proces wyżarzania w metalurgii. Algorytm iteracyjnie wprowadza drobne, losowe zmiany w grafiku. Co kluczowe, potrafi akceptować tymczasowo gorsze rozwiązania, aby 'uciec' z lokalnych optimów i lepiej przeszukać przestrzeń możliwych grafików."
                },
                new AlgorithmChoice
                {
                    Type = SolverType.TabuSearch,
                    Name = "TabuSearchSolver",
                    DescriptionHeader = CreateHeader("TabuSearchSolver", "algorytm przeszukiwania z zakazami"),
                    Description = "Zaawansowana forma przeszukiwania lokalnego. W każdej iteracji wybiera najlepszą możliwą modyfikację grafiku, nawet jeśli prowadzi ona do chwilowego pogorszenia wyniku. Aby uniknąć zapętlenia, prowadzi krótkoterminową pamięć – 'listę tabu' – która zabrania powrotu do niedawno odwiedzonych stanów."
                },
                new AlgorithmChoice
                {
                    Type = SolverType.AntColony,
                    Name = "AntColonySolver",
                    DescriptionHeader = CreateHeader("AntColonySolver", "algorytam kolonii mrówek"),
                    Description = "Algorytm inspirowany inteligencją rozproszoną, obserwowaną u mrówek. Wiele wirtualnych 'mrówek' jednocześnie konstruuje grafiki, zostawiając na najlepszych ścieżkach cyfrowy 'feromon'. Kolejne mrówki chętniej podążają za silniejszym śladem feromonowym, co prowadzi do szybkiego znalezienia bardzo dobrych rozwiązań."
                }
            };

            foreach (var option in AlgorithmOptions)
            {
                option.PropertyChanged += (s, e) =>
                {
                    if (e.PropertyName == nameof(AlgorithmChoice.IsSelected) && option.IsSelected)
                    {
                        ActiveDescription = option;
                    }
                };
            }

            var selectedOption = AlgorithmOptions.FirstOrDefault(o => o.Type == currentSolver) ?? AlgorithmOptions.First();
            selectedOption.IsSelected = true;

            ComparisonData = new List<AlgorithmInfo>
            {
                new AlgorithmInfo("BacktrackingSolver", "Przeszukiwanie zupełne", "Deterministyczny", "Nie", "Gwarancja znalezienia wyniku najlepszego z możliwych.", "Od b. krótkiego do astronomicznie długiego", "Niskie"),
                new AlgorithmInfo("AStarSolver", "Przeszukiwanie heurystyczne", "Deterministyczny", "Tak", "Wynik bardzo wysokiej jakości (bez gwarancji optimum).", "Krótki / Średni", "Wysokie"),
                new AlgorithmInfo("GeneticSolver", "Metaheurystyka ewolucyjna", "Stochastyczny", "Tak", "Wynik bardzo wysokiej jakości, bliski najlepszemu.", "Krótki", "Średnie / Wysokie"),
                new AlgorithmInfo("SimulatedAnnealingSolver", "Metaheurystyka", "Stochastyczny", "Nie", "Wynik zazwyczaj bardzo dobry, lecz bez gwarancji bliskości do wyniku najlepszego z możliwych.", "Średni", "Niskie"),
                new AlgorithmInfo("TabuSearchSolver", "Metaheurystyka", "Stochastyczny", "Nie", "Wynik bardzo wysokiej jakości, bliski najlepszemu.", "Krótki", "Średnie"),
                new AlgorithmInfo("AntColonySolver", "Metaheurystyka (inteligencja rozproszona)", "Stochastyczny", "Tak", "Wynik bardzo wysokiej jakości, bliski najlepszemu.", "Krótki", "Wysokie")
            };
        }

        private TextBlock CreateHeader(string name, string description)
        {
            var tb = new TextBlock();
            tb.Inlines.Add(new Bold(new Run(name)));
            tb.Inlines.Add(new Run($" ({description})"));
            return tb;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void AlgorithmLabel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is AlgorithmChoice choice)
            {
                choice.IsSelected = true;
            }
        }

        private void BenchmarkButton_Click(object sender, RoutedEventArgs e)
        {
            var benchmarkWindow = new BenchmarkWindow
            {
                Owner = this
            };
            benchmarkWindow.ShowDialog();
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}