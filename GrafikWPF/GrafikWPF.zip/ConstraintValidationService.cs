﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GrafikWPF
{
    /// <summary>
    /// Zapewnia scentralizowane, statyczne metody do walidacji ograniczeń i naprawy grafików.
    /// Jest to jedyne źródło prawdy o "twardych" zasadach generowania grafiku.
    /// </summary>
    public static class ConstraintValidationService
    {
        /// <summary>
        /// Znajduje listę lekarzy, którzy mogą legalnie objąć dyżur w danym dniu,
        /// biorąc pod uwagę stan już przypisanych dyżurów.
        /// </summary>
        public static List<Lekarz> GetValidCandidatesForDay(
            DateTime dzien,
            GrafikWejsciowy daneWejsciowe,
            IReadOnlyDictionary<DateTime, Lekarz?> aktualnePrzypisania,
            IReadOnlyDictionary<string, int> aktualneOblozenie,
            IReadOnlySet<string> wykorzystaneDyzuryW)
        {
            var kandydaci = new List<Lekarz>();
            var dniMiesiaca = daneWejsciowe.DniWMiesiacu;
            var lekarzDniaPoprzedniego = dzien > dniMiesiaca.First() && aktualnePrzypisania.TryGetValue(dzien.AddDays(-1), out var wczorajszyLekarz) ? wczorajszyLekarz : null;

            foreach (var lekarz in daneWejsciowe.Lekarze)
            {
                // 1. Sprawdzenie limitu dyżurów
                int maksymalnaLiczbaDyzurow = daneWejsciowe.LimityDyzurow.GetValueOrDefault(lekarz.Symbol, 0);
                if (maksymalnaLiczbaDyzurow <= 0 || aktualneOblozenie.GetValueOrDefault(lekarz.Symbol, 0) >= maksymalnaLiczbaDyzurow)
                    continue;

                // 2. Sprawdzenie podstawowej dostępności
                var dostepnoscDzis = daneWejsciowe.Dostepnosc[dzien][lekarz.Symbol];
                if (dostepnoscDzis is TypDostepnosci.Niedostepny or TypDostepnosci.Urlop or TypDostepnosci.DyzurInny)
                    continue;

                // 3. Sprawdzenie dyżuru dzień po dniu
                bool maBardzoChce = (dostepnoscDzis == TypDostepnosci.BardzoChce);
                if (!maBardzoChce && lekarzDniaPoprzedniego?.Symbol == lekarz.Symbol)
                    continue;

                // 4. Sprawdzenie sąsiedztwa z "Innym Dyżurem"
                if (!maBardzoChce)
                {
                    // Sprawdzenie dnia następnego
                    var jutro = dzien.AddDays(1);
                    if (daneWejsciowe.Dostepnosc.ContainsKey(jutro) && daneWejsciowe.Dostepnosc[jutro][lekarz.Symbol] == TypDostepnosci.DyzurInny)
                        continue;

                    // Sprawdzenie dnia poprzedniego
                    var wczoraj = dzien.AddDays(-1);
                    if (daneWejsciowe.Dostepnosc.ContainsKey(wczoraj) && daneWejsciowe.Dostepnosc[wczoraj][lekarz.Symbol] == TypDostepnosci.DyzurInny)
                        continue;
                }

                // 5. Sprawdzenie limitu dyżurów warunkowych
                if (dostepnoscDzis == TypDostepnosci.MogeWarunkowo && wykorzystaneDyzuryW.Contains(lekarz.Symbol))
                    continue;

                kandydaci.Add(lekarz);
            }
            return kandydaci;
        }

        /// <summary>
        /// Naprawia kompletny grafik, usuwając z niego wszystkie wpisy naruszające twarde ograniczenia.
        /// </summary>
        public static void RepairSchedule(Dictionary<DateTime, Lekarz?> grafik, GrafikWejsciowy daneWejsciowe)
        {
            // Pętla naprawcza - powtarzamy, dopóki nie będzie żadnych zmian w iteracji
            bool dokonanoZmiany;
            do
            {
                dokonanoZmiany = false;
                var oblozenie = ObliczOblozenie(grafik, daneWejsciowe);
                var wykorzystaneW = ObliczWykorzystaneW(grafik, daneWejsciowe);

                // Naprawa przekroczonych limitów dyżurów
                foreach (var lekarzSymbol in oblozenie.Keys)
                {
                    var limit = daneWejsciowe.LimityDyzurow.GetValueOrDefault(lekarzSymbol, 0);
                    while (oblozenie[lekarzSymbol] > limit)
                    {
                        var dyzuryDoUsuniecia = grafik.Where(g => g.Value?.Symbol == lekarzSymbol).ToList();
                        if (dyzuryDoUsuniecia.Any())
                        {
                            // ### ZMIANA ### Nowa, inteligentna logika usuwania najmniej wartościowego dyżuru
                            var dyzurDoUsuniecia = dyzuryDoUsuniecia
                                .OrderBy(d => GetAvailabilityScore(daneWejsciowe.Dostepnosc[d.Key][d.Value!.Symbol])) // Sortuj po wartości dostępności (rosnąco)
                                .ThenByDescending(d => d.Key) // Potem po dacie (malejąco), aby chronić początek miesiąca
                                .First();

                            grafik[dyzurDoUsuniecia.Key] = null;
                            oblozenie[lekarzSymbol]--;
                            dokonanoZmiany = true;
                        }
                        else break;
                    }
                }

                // Naprawa wielokrotnych dyżurów warunkowych ('W')
                foreach (var symbolLekarza in wykorzystaneW.Keys)
                {
                    while (wykorzystaneW[symbolLekarza] > 1)
                    {
                        var dyzuryWdoUsuniecia = grafik.FirstOrDefault(g => g.Value?.Symbol == symbolLekarza && daneWejsciowe.Dostepnosc[g.Key][g.Value.Symbol] == TypDostepnosci.MogeWarunkowo);
                        if (dyzuryWdoUsuniecia.Key != default)
                        {
                            grafik[dyzuryWdoUsuniecia.Key] = null;
                            wykorzystaneW[symbolLekarza]--;
                            dokonanoZmiany = true;
                        }
                        else break;
                    }
                }

                // Naprawa konfliktów dzień po dniu i z "Innym Dyżurem"
                foreach (var dzien in daneWejsciowe.DniWMiesiacu)
                {
                    var lekarz = grafik[dzien];
                    if (lekarz == null) continue;

                    if (daneWejsciowe.Dostepnosc[dzien][lekarz.Symbol] == TypDostepnosci.BardzoChce)
                        continue; // "Bardzo Chcę" ignoruje te reguły

                    // Sprawdzenie dnia poprzedniego
                    var wczoraj = dzien.AddDays(-1);
                    if (grafik.ContainsKey(wczoraj))
                    {
                        if (grafik[wczoraj]?.Symbol == lekarz.Symbol || daneWejsciowe.Dostepnosc[wczoraj][lekarz.Symbol] == TypDostepnosci.DyzurInny)
                        {
                            grafik[dzien] = null;
                            dokonanoZmiany = true;
                            continue;
                        }
                    }

                    // Sprawdzenie dnia następnego
                    var jutro = dzien.AddDays(1);
                    if (grafik.ContainsKey(jutro) && daneWejsciowe.Dostepnosc[jutro][lekarz.Symbol] == TypDostepnosci.DyzurInny)
                    {
                        grafik[dzien] = null;
                        dokonanoZmiany = true;
                    }
                }

            } while (dokonanoZmiany);
        }

        // ### NOWA METODA ### Pomocnicza funkcja do oceny "wartości" dyżuru
        private static int GetAvailabilityScore(TypDostepnosci typ)
        {
            return typ switch
            {
                TypDostepnosci.MogeWarunkowo => 0,
                TypDostepnosci.Moge => 1,
                TypDostepnosci.Chce => 2,
                TypDostepnosci.BardzoChce => 3,
                _ => 99
            };
        }

        private static Dictionary<string, int> ObliczOblozenie(IReadOnlyDictionary<DateTime, Lekarz?> genes, GrafikWejsciowy daneWejsciowe)
        {
            var oblozenie = daneWejsciowe.Lekarze.ToDictionary(l => l.Symbol, l => 0);
            foreach (var lekarz in genes.Values.Where(l => l != null))
            {
                if (lekarz != null) oblozenie[lekarz.Symbol]++;
            }
            return oblozenie;
        }

        private static Dictionary<string, int> ObliczWykorzystaneW(IReadOnlyDictionary<DateTime, Lekarz?> genes, GrafikWejsciowy daneWejsciowe)
        {
            var wykorzystane = daneWejsciowe.Lekarze.ToDictionary(l => l.Symbol, l => 0);
            foreach (var para in genes)
            {
                if (para.Value != null && daneWejsciowe.Dostepnosc.ContainsKey(para.Key) && daneWejsciowe.Dostepnosc[para.Key][para.Value.Symbol] == TypDostepnosci.MogeWarunkowo)
                {
                    wykorzystane[para.Value.Symbol]++;
                }
            }
            return wykorzystane;
        }
    }
}